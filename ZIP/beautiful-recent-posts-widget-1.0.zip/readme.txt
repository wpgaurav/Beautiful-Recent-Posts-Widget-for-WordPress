=== Beautiful Recent Posts Widget ===
Contributors: gauravtiwari
Donate link: http://gauravtiwari.org/donate/
Tags: widget
Requires at least: 3.5
Tested up to: 4.0
Stable Tag: 4.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Beautiful Recent Posts Widget (BRPW) is a clean minimal sidebar widget to showcase your recent articles in a clean & beautiful way.

== Description ==

* Lightweight – Just 5kB in size.
* Tested on WordPress 3.5+ // WordPress 4.0 recommended.
* Customize the way you want.
* Link to one of your blog pages.
* Free support and future updates at [personal blog](http://gauravtiwari.org/question-hub/ "Q&A")

== Installation ==

1. Install to /wp-content/plugins/ folder or upload through Dashboard ⇒Plugins ⇒Add New.
2. Activate.
3. Regenerate Thumbnails
4. Go to Appearance ⇒ Widgets and drag Beautiful Recent Posts widget to a sidebar.


== Changelog ==

= 1.0 =
* Initial Release
